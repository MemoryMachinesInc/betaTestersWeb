# AI Integration - Engramme Assistant

## What Changed

The Chrome extension now uses OpenAI's API to intelligently improve your email drafts by incorporating memory content, instead of just inserting the raw memory text.

## How It Works

When you click on a memory card in compose mode:

1. **Extracts current email text** from the Gmail compose window
2. **Calls OpenAI API** with both the current draft and the memory content
3. **AI rewrites the email** to naturally incorporate the memory
4. **Replaces the email** with the improved version

## Setup Instructions

**The extension comes pre-configured with an OpenAI API key** - you can start using it immediately!

1. **Load the extension in Chrome**:
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (top right)
   - Click "Load unpacked"
   - Select the extension folder

2. **Use it**:
   - Open Gmail and compose an email
   - Type some text in your draft (50+ characters)
   - Click any memory card
   - Watch as AI improves your email!

3. **Optional - Use your own API key**:
   - Click the extension icon in Chrome
   - Replace the pre-filled OpenAI API key with your own
   - Click "Save Settings"

## Customizing the AI Prompt

The AI prompt can be customized in **content.js** at **lines 714-740**.

### Location of the Prompt

File: `content.js`
Function: `improveEmailWithMemory()`
Lines: **714-740**

### Current Prompt Structure

```javascript
const systemPrompt = `You are an AI assistant helping to improve email composition.
You will be given:
1. The current draft email text
2. A relevant memory/context that the user wants to incorporate

Your task is to rewrite the email to naturally incorporate the memory content while:
- Maintaining the original intent and tone of the email
- Seamlessly integrating the memory details
- Keeping the email concise and professional
- Preserving any specific information from the original draft

Only return the improved email text, nothing else.`;

const userPrompt = `Current email draft:
"""
${currentEmailText}
"""

Memory to incorporate:
"""
${memoryContent}
"""

Please rewrite the email to naturally incorporate this memory.`;
```

### How to Modify the Prompt

1. Open `content.js`
2. Find the `improveEmailWithMemory()` function
3. Look for the comment `// ====== PROMPT CONFIGURATION ======` (line 714)
4. Edit the `systemPrompt` or `userPrompt` variables
5. Save the file
6. Reload the extension in Chrome

### Example Customizations

**Make emails more casual:**
```javascript
const systemPrompt = `You are helping write friendly, casual emails.
Take the draft and memory, and rewrite in a warm, conversational tone.
Use casual language, contractions, and keep it brief.`;
```

**Make emails more formal:**
```javascript
const systemPrompt = `You are helping write formal business emails.
Incorporate the memory details while maintaining professional language,
proper grammar, and business email etiquette.`;
```

**Focus on specific aspects:**
```javascript
const systemPrompt = `You are helping write persuasive sales emails.
Use the memory to add personal context and build rapport.
Focus on benefits, create urgency, and end with a clear call-to-action.`;
```

## OpenAI API Configuration

Current settings (line 750):
- **Model**: `gpt-4` (you can change to `gpt-3.5-turbo` for faster/cheaper responses)
- **Temperature**: `0.7` (0.0 = deterministic, 1.0 = creative)
- **Max tokens**: `1000` (maximum length of AI response)

## Fallback Behavior

If OpenAI API fails (no API key, network error, etc.):
- Falls back to simple text insertion
- Shows a warning message
- Your email still gets the memory content appended

## Feedback Messages

The extension shows different colored notifications:
- 🤖 **Blue**: AI is processing (shown while waiting for OpenAI)
- ✓ **Green**: Success (email improved successfully)
- ⚠️ **Orange**: Warning (fell back to simple insertion)
- ❌ **Red**: Error (API key missing or API error)

## Files Modified

1. **content.js**:
   - Added `getOpenAIKey()` function
   - Added `improveEmailWithMemory()` function (contains the prompt)
   - Modified `insertMemory()` to call OpenAI
   - Updated `showFeedback()` to support multiple feedback types

2. **options.html**:
   - Added OpenAI API key input field

3. **options.js**:
   - Added API key saving/loading logic

## Privacy & Security

- Your OpenAI API key is stored locally in Chrome's sync storage
- Email content is sent to OpenAI's API for processing
- No data is stored on external servers (except OpenAI's processing)
- Consider OpenAI's data usage policies for sensitive emails

## Cost Considerations

- GPT-4 costs approximately $0.03 per 1K input tokens + $0.06 per 1K output tokens
- Average email improvement: ~$0.01-0.05 per request
- Consider switching to `gpt-3.5-turbo` (10x cheaper) if cost is a concern

## Troubleshooting

**"⚠️ OpenAI API key not configured"**
- You need to add your API key in the extension settings

**"⚠️ OpenAI API error: ..."**
- Check your API key is valid
- Ensure you have credits in your OpenAI account
- Check your internet connection

**AI response is too long/short**
- Adjust `max_tokens` parameter in content.js (line 756)

**AI tone is wrong**
- Modify the `systemPrompt` in content.js (lines 716-727)
