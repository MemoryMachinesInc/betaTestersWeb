# Engramme Assistant - File Structure

## Overview

This Chrome extension provides contextual memory suggestions on Gmail and web pages using the Engramme API.

```
engramme-extension/
├── manifest.json           # Extension configuration
├── assets/                 # Static assets
├── docs/                   # Documentation
├── scripts/                # Build/publish scripts
└── src/                    # Source code
```

---

## Source Files (`src/`)

### Entry Points

| File | Description |
|------|-------------|
| `background.js` | Service worker handling API calls, message routing, and background tasks |
| `content.js` | Content script entry point - initializes modules and wires callbacks |

### Core (`src/core/`)

| File | Description |
|------|-------------|
| `state.js` | Global state container and shared utilities. Establishes `window.Engramme` namespace with state, utils, and constants used across all modules |

### API Layer (`src/api/`)

| File | Description |
|------|-------------|
| `memory-recall.js` | Memory recall API client. Handles requests to `/v1/memories/recall` with caching and request deduplication |
| `memory-refresh.js` | Memory refresh orchestration. Coordinates when to update suggestions for compose, view, and generic page contexts |
| `openai.js` | OpenAI integration. Improves email drafts by incorporating memory content using GPT-4 |

### Site Behaviors (`src/sites/`)

| File | Description |
|------|-------------|
| `gmail.js` | Gmail site behavior. DOM observer, compose detection, email extraction |

*Future site-specific handlers will be added here (e.g., `google-docs.js`, `reddit.js`)*

### Extraction Utilities (`src/extraction/`)

| File | Description |
|------|-------------|
| `scrapers.js` | Shared content scrapers. Extractors for Google Docs, Search, Reddit, Amazon, Wikipedia, Instagram, ChatGPT |
| `monitor.js` | Page content monitoring. Watches for changes on non-Gmail pages and triggers memorization |

### UI Components (`src/ui/`)

| File | Description |
|------|-------------|
| `overlay.js` | Main overlay panel. Creates, positions, shows/hides the sidebar panel with resize support |
| `memory-cards.js` | Memory card rendering. Displays memory cards in list view and handles detail view navigation |
| `feedback.js` | Feedback system. Manages thumbs up/down ratings, comments, and submission to backend |
| `chat.js` | Chat mode UI. Provides conversational interface to query memories |

### Popup (`src/popup/`)

| File | Description |
|------|-------------|
| `popup.html` | Extension popup UI markup |
| `popup.js` | Popup logic. API key configuration and settings management |

### Services (`src/services/`)

| File | Description |
|------|-------------|
| `firebase-config.js` | Firebase configuration |
| `firestore-service.js` | Firestore database service |

---

## Scripts (`scripts/`)

| File | Description |
|------|-------------|
| `publish.sh` | Build and publish script |
| `diagnostic.js` | Standalone diagnostic script for Service Worker console |

---

## Styles (`assets/styles/`)

| File | Description |
|------|-------------|
| `overlay.css` | Panel shell styles - header, resize handle, scrollbars, responsive layout |
| `memory-cards.css` | Memory card styles - card layout, avatars, detail view, actions |
| `feedback.css` | Feedback panel styles - rating buttons, comment inputs, submit buttons |
| `chat.css` | Chat mode styles - messages, input, toggle button |

---

## Module Dependencies

```
                    ┌─────────────┐
                    │  state.js   │  (Core state & utils)
                    └──────┬──────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ▼                  ▼                  ▼
   ┌─────────┐       ┌─────────────┐     ┌─────────┐
   │ scrapers│       │memory-recall│     │  gmail  │
   └─────────┘       └─────────────┘     └─────────┘
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
                           ▼
                   ┌───────────────┐
                   │memory-refresh │  (Orchestration)
                   └───────┬───────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ▼                  ▼                  ▼
   ┌─────────┐       ┌─────────────┐    ┌──────────┐
   │ overlay │       │memory-cards │    │ feedback │
   └─────────┘       └─────────────┘    └──────────┘
                           │
                           ▼
                    ┌─────────────┐
                    │  content.js │  (Entry point)
                    └─────────────┘
```

---

## Namespace Exports

All modules export to `window.Engramme`:

| Namespace | Module | Key Functions |
|-----------|--------|---------------|
| `Engramme.state` | state.js | Global state object |
| `Engramme.utils` | state.js | `isExtensionValid()`, `evaluateQueryChange()`, `debounce()` |
| `Engramme.api` | memory-recall.js | `findRelevantMemories()`, `getCachedMemories()` |
| `Engramme.extractors` | scrapers.js | `getGenericPageContent()`, `getGoogleDocsContent()` |
| `Engramme.gmail` | sites/gmail.js | `startObserver()`, `getEmailContent()` |
| `Engramme.overlay` | overlay.js | `create()`, `show()`, `hide()`, `close()` |
| `Engramme.memoryDisplay` | memory-cards.js | `display()`, `showDetail()` |
| `Engramme.feedback` | feedback.js | `submit()`, `hasFeedback()` |
| `Engramme.chat` | chat.js | `toggle()`, `send()` |
| `Engramme.memoryRefresh` | memory-refresh.js | `updateForCompose()`, `updateForView()` |
| `Engramme.genericPage` | monitor.js | `startMonitoring()`, `memorize()` |
| `Engramme.openai` | openai.js | `insertMemory()`, `improveEmail()` |

---

## Load Order

Content scripts are loaded in this order (defined in `manifest.json`):

1. `core/state.js` - Establishes namespace
2. `extraction/scrapers.js` - Shared content extractors
3. `api/memory-recall.js` - API client
4. `sites/gmail.js` - Gmail site behavior
5. `ui/feedback.js` - Feedback UI
6. `ui/chat.js` - Chat mode
7. `ui/overlay.js` - Panel UI
8. `ui/memory-cards.js` - Card rendering
9. `api/openai.js` - AI integration
10. `extraction/monitor.js` - Page monitoring
11. `api/memory-refresh.js` - Refresh orchestration
12. `content.js` - Entry point (wires everything)
