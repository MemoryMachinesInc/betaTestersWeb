// meet-tab-capture.js - Offscreen tab audio capture for Google Meet
// Runs in an offscreen document to access Media APIs in MV3.

(() => {
  'use strict';

  // Note: ELEVENLABS_PROXY_BASE is set dynamically based on environment
  let ELEVENLABS_PROXY_BASE = 'https://memory-machines-backend-prod-42us6ic5ya-uc.a.run.app'; // Default to prod
  const ELEVENLABS_LOCAL_PROXY_BASE = 'http://localhost:5002';
  const TARGET_SAMPLE_RATE = 16000;

  // Get backend URL from storage (set by Developer Mode)
  async function getBackendURL() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(['devModeEnabled', 'selectedEnvironment'], (result) => {
        if (result.devModeEnabled && result.selectedEnvironment) {
          // Map environment to backend URL
          const backendURLs = {
            'prod': 'https://memory-machines-backend-prod-42us6ic5ya-uc.a.run.app'
          };
          resolve(backendURLs[result.selectedEnvironment] || backendURLs['prod']);
        } else {
          resolve('https://memory-machines-backend-prod-42us6ic5ya-uc.a.run.app');
        }
      });
    });
  }

  // Initialize backend URL
  getBackendURL().then(url => {
    ELEVENLABS_PROXY_BASE = url;
    console.log('Meet Tab Capture backend URL:', ELEVENLABS_PROXY_BASE);
  });

  let isCapturing = false;
  let currentTabId = null;
  let tabStream = null;
  let tabAudioContext = null;
  let tabProcessor = null;
  let tabWebSocket = null;
  let tabSessionReady = false;

  function resampleToTargetRate(input, inputSampleRate, targetSampleRate) {
    if (inputSampleRate === targetSampleRate) {
      return input;
    }

    const ratio = inputSampleRate / targetSampleRate;
    const outputLength = Math.round(input.length / ratio);
    const output = new Float32Array(outputLength);
    let offset = 0;

    for (let i = 0; i < outputLength; i += 1) {
      const nextOffset = Math.round((i + 1) * ratio);
      let sum = 0;
      let count = 0;
      for (let j = offset; j < nextOffset && j < input.length; j += 1) {
        sum += input[j];
        count += 1;
      }
      output[i] = count ? sum / count : 0;
      offset = nextOffset;
    }

    return output;
  }

  function float32ToInt16(float32Data) {
    const int16Data = new Int16Array(float32Data.length);
    for (let i = 0; i < float32Data.length; i++) {
      const s = Math.max(-1, Math.min(1, float32Data[i]));
      int16Data[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return int16Data;
  }

  function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  function sendToTab(tabId, payload) {
    if (!tabId) return;
    chrome.tabs.sendMessage(tabId, payload, () => {
      // Ignore errors if the tab is gone.
      void chrome.runtime.lastError;
    });
  }

  function getElevenLabsProxyBase() {
    return new Promise((resolve) => {
      if (!chrome?.storage?.local?.get) {
        resolve(ELEVENLABS_PROXY_BASE);
        return;
      }
      chrome.storage.local.get(['elevenLabsProxyBase', 'useLocalElevenLabs'], (result) => {
        if (result?.elevenLabsProxyBase) {
          resolve(result.elevenLabsProxyBase);
          return;
        }
        if (result?.useLocalElevenLabs) {
          resolve(ELEVENLABS_LOCAL_PROXY_BASE);
          return;
        }
        resolve(ELEVENLABS_PROXY_BASE);
      });
    });
  }

  async function connectToElevenLabs() {
    const base = await getElevenLabsProxyBase();
    return new Promise((resolve, reject) => {
      try {
        const url = `${base.replace(/^http/i, 'ws')}/api/elevenlabs/ws`;
        const ws = new WebSocket(url);

        ws.onopen = () => resolve(ws);
        ws.onerror = (error) => reject(error);
        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            const messageType = data.message_type || data.type || 'unknown';
            if (messageType === 'session_started') {
              tabSessionReady = true;
              return;
            }

            const transcript = data.text || '';
            const isFinal = data.is_final ?? true;
            const isCommitted = messageType === 'committed_transcript' ||
              messageType === 'committed_transcript_with_timestamps' ||
              messageType === 'final_transcript';
            const isTranscript = messageType === 'transcript' || messageType === 'final_transcript';

            if (transcript && transcript.trim() && (isCommitted || (isTranscript && isFinal))) {
              const entry = {
                speaker: 'Other',
                text: transcript.trim(),
                timestamp: new Date().toISOString()
              };
              sendToTab(currentTabId, { action: 'meetTabTranscript', entry });
            }
          } catch (error) {
            sendToTab(currentTabId, {
              action: 'meetTabCaptureError',
              error: 'ElevenLabs parse error'
            });
          }
        };
      } catch (error) {
        reject(error);
      }
    });
  }

  function setupAudioProcessor(stream, getWebSocket, getSessionReady) {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioContext.createMediaStreamSource(stream);
    const bufferSize = 4096;
    const processor = audioContext.createScriptProcessor(bufferSize, 1, 1);
    const inputSampleRate = audioContext.sampleRate;

    processor.onaudioprocess = (e) => {
      const ws = getWebSocket();
      if (!isCapturing || !getSessionReady() || !ws || ws.readyState !== WebSocket.OPEN) {
        return;
      }
      const inputBuffer = e.inputBuffer;
      const channelCount = inputBuffer.numberOfChannels;
      const length = inputBuffer.length;
      const mixed = new Float32Array(length);

      if (channelCount === 1) {
        mixed.set(inputBuffer.getChannelData(0));
      } else {
        for (let ch = 0; ch < channelCount; ch++) {
          const channelData = inputBuffer.getChannelData(ch);
          for (let i = 0; i < length; i++) {
            mixed[i] += channelData[i];
          }
        }
        const inv = 1 / channelCount;
        for (let i = 0; i < length; i++) {
          mixed[i] *= inv;
        }
      }

      const resampled = resampleToTargetRate(mixed, inputSampleRate, TARGET_SAMPLE_RATE);
      const int16Data = float32ToInt16(resampled);
      const base64Audio = arrayBufferToBase64(int16Data.buffer);

      ws.send(JSON.stringify({
        message_type: 'input_audio_chunk',
        audio_base_64: base64Audio,
        commit: false,
        sample_rate: TARGET_SAMPLE_RATE
      }));
    };

    source.connect(processor);
    processor.connect(audioContext.destination);

    return { audioContext, processor };
  }

  async function startTabCapture(streamId, tabId) {
    if (!streamId) {
      throw new Error('Missing stream ID');
    }

    if (isCapturing) {
      stopTabCapture();
    }

    currentTabId = tabId;
    isCapturing = true;
    tabSessionReady = false;

    tabStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId
        }
      },
      video: false
    });

    const audioTracks = tabStream.getAudioTracks();
    if (!audioTracks.length) {
      throw new Error('No audio track in tab capture');
    }

    const { audioContext, processor } = setupAudioProcessor(
      tabStream,
      () => tabWebSocket,
      () => tabSessionReady
    );
    tabWebSocket = await connectToElevenLabs();
    tabProcessor = processor;
    tabAudioContext = audioContext;
  }

  function stopTabCapture() {
    isCapturing = false;

    if (tabWebSocket && tabWebSocket.readyState === WebSocket.OPEN) {
      try {
        tabWebSocket.close();
      } catch (e) {}
    }
    tabWebSocket = null;
    tabSessionReady = false;

    if (tabProcessor) {
      tabProcessor.disconnect();
      tabProcessor = null;
    }
    if (tabAudioContext) {
      tabAudioContext.close();
      tabAudioContext = null;
    }
    if (tabStream) {
      tabStream.getTracks().forEach((track) => track.stop());
      tabStream = null;
    }
    currentTabId = null;
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request?.action === 'offscreenStartTabCapture') {
      startTabCapture(request.streamId, request.tabId)
        .then(() => sendResponse({ success: true }))
        .catch((error) => {
          sendToTab(request.tabId, {
            action: 'meetTabCaptureError',
            error: error.message || 'Tab capture failed'
          });
          sendResponse({ success: false, error: error.message });
        });
      return true;
    }

    if (request?.action === 'offscreenStopTabCapture') {
      stopTabCapture();
      sendResponse({ success: true });
    }
  });
})();
