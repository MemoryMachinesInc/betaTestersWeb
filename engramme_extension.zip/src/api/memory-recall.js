// memory-recall.js - Memory recall API client with caching
// Handles API requests to fetch relevant memories based on context
// Depends on: core/state.js

(function() {
    'use strict';

    const api = {};
    const state = window.Engramme.state;
    const constants = window.Engramme.constants;

    /**
     * Get cached memories for a given cache key
     * @param {string} cacheKey - The cache key to look up
     * @returns {Object|null} Cached entry with memories and fetchedAt, or null if not found/expired
     */
    api.getCachedMemories = function(cacheKey) {
        const entry = state.recallCache.get(cacheKey);
        if (!entry) return null;
        if (Date.now() - entry.fetchedAt > constants.REQUEST_CACHE_TTL_MS) {
            state.recallCache.delete(cacheKey);
            return null;
        }
        return entry;
    };

    /**
     * Cache memories for a given cache key
     * @param {string} cacheKey - The cache key to store under
     * @param {Array} memories - Array of memory objects to cache
     */
    api.setCachedMemories = function(cacheKey, memories) {
        state.recallCache.set(cacheKey, { memories, fetchedAt: Date.now() });
    };

    /**
     * Start a new request and track it
     * @param {string} requestKey - Unique key for this request
     * @param {boolean} isMeaningfulChange - Whether this represents a meaningful query change
     * @returns {number} The request ID
     */
    api.startRequest = function(requestKey, isMeaningfulChange) {
        state.requestCounter += 1;
        const requestId = state.requestCounter;
        if (isMeaningfulChange) {
            state.latestEligibleRequestId = requestId;
            state.latestEligibleRequestKey = requestKey;
        }
        return requestId;
    };

    /**
     * Search for relevant memories via the API
     * @param {string} text - The text to search for relevant memories
     * @returns {Promise<{memories: Array, error: boolean}>} Search results
     */
    api.findRelevantMemories = async function(text) {
        console.log(`🔍 Searching for memories via API: "${text.substring(0, 100)}..."`);

        if (!state.isApiConfigured) {
            console.warn('⚠️ API not configured');
            return { memories: [], error: true };
        }

        // Store the payload for debug display (show first 1000 chars, matching background.js truncation)
        // Note: URL is dynamically determined by background.js based on selected environment
        state.lastRecallPayload = {
            url: '[Environment-specific URL determined by background.js]',
            method: 'POST',
            headers: {
                'x-api-key': '[HIDDEN]'
            },
            formData: {
                text: text.length > 1000 ? text.slice(0, 1000) : text,
                top_k: '3'
            },
            textLength: text.length,
            timestamp: new Date().toISOString(),
            note: 'Actual URL depends on Developer Mode environment setting'
        };

        try {
            // Send message to background script to search memories
            const response = await chrome.runtime.sendMessage({
                action: 'searchMemories',
                text: text
            });

            if (response.success) {
                console.log(`✅ Found ${response.memories.length} memories from API`);
                return { memories: response.memories || [], error: false };
            }
            console.error('❌ Memory search failed:', response.error);
            return { memories: [], error: true };
        } catch (error) {
            console.error('❌ Error calling memory search:', error);
            return { memories: [], error: true };
        }
    };

    // Export api to namespace
    window.Engramme.api = api;

    console.log('✅ Engramme API loaded');
})();

