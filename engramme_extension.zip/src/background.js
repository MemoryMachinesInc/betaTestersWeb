// background.js - API-based memory loading
console.log('🔧 Engramme Assistant starting...');

// Wrap everything in try-catch to prevent service worker crashes
try {

// Environment configuration - inline since we can't use importScripts with type: "module"
const ENVIRONMENTS = {
  prod: {
    apiGateway: 'https://memorymachines-gateway-prod-btf57kda.uc.gateway.dev',
    authApiBase: 'https://memorymachines-gateway-prod-btf57kda.uc.gateway.dev',
    backendUrl: 'https://memory-machines-backend-prod-42us6ic5ya-uc.a.run.app',
    firebase: { apiKey: 'AIzaSyB7DIVqzT72Pg9KAhJQCxNgBw7ZeTyLkzc' }
  }
};

async function getCurrentEnvironment() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['devModeEnabled', 'selectedEnvironment'], (result) => {
      const env = result.devModeEnabled && result.selectedEnvironment
        ? result.selectedEnvironment
        : 'prod';
      resolve(ENVIRONMENTS[env] || ENVIRONMENTS['prod']);
    });
  });
}

async function getEnvironmentName() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['devModeEnabled', 'selectedEnvironment'], (result) => {
      const env = result.devModeEnabled && result.selectedEnvironment
        ? result.selectedEnvironment
        : 'prod';
      resolve(env);
    });
  });
}

// API configuration - will be set dynamically based on environment
let API_BASE_URL;
let AUTH_API_BASE;
let FIREBASE_API_KEY;
let BACKEND_URL;

// Initialize environment configuration
async function initializeEnvironmentConfig() {
  const env = await getCurrentEnvironment();
  API_BASE_URL = env.apiGateway;
  AUTH_API_BASE = env.authApiBase;
  FIREBASE_API_KEY = env.firebase.apiKey;
  BACKEND_URL = env.backendUrl;

  const envName = await getEnvironmentName();
  console.log(`🌍 Environment: ${envName.toUpperCase()}`);
  console.log(`📡 API Gateway: ${API_BASE_URL}`);
  console.log(`🔐 Backend URL: ${BACKEND_URL}`);
}

// Call initialization immediately
initializeEnvironmentConfig();

const OFFSCREEN_DOCUMENT_PATH = 'src/offscreen/meet-tab-capture.html';
let activeTabCaptureTabId = null;

function sendOffscreenMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ success: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response);
    });
  });
}

async function ensureOffscreenDocument() {
  if (!chrome.offscreen) {
    throw new Error('Offscreen API not available');
  }
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  });
  if (contexts.length > 0) {
    return;
  }
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ['USER_MEDIA'],
    justification: 'Capture Google Meet tab audio for transcription'
  });
}

// Format date for display: "X days ago" (1-14 days) or "MM/DD/YYYY"
function formatWhen(whenObj) {
  if (!whenObj) return '';

  let dtstr;
  if (typeof whenObj === 'string') {
    dtstr = whenObj;
  } else {
    dtstr = whenObj.event_start_time ?? '';
  }

  if (!dtstr) return '';
  const lowered = dtstr.toLowerCase();
  if (['unknown', 'n/a', 'na', ''].includes(lowered)) return '';

  // Year only (e.g., "2025")
  if (/^\d{4}$/.test(dtstr)) {
    return dtstr;
  }

  // Year-month only (e.g., "2025-12")
  if (/^\d{4}-(\d{2})$/.test(dtstr)) {
    const match = dtstr.match(/^(\d{4})-(\d{2})$/);
    const month = parseInt(match[2], 10);
    const year = match[1];
    return `${month.toString().padStart(2, '0')}/${year}`;
  }

  // Try to parse as date
  let dt;
  try {
    dt = new Date(dtstr);
    if (isNaN(dt.getTime())) return dtstr;
  } catch {
    return dtstr;
  }

  // Calculate days ago
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dateOnly = new Date(dt);
  dateOnly.setHours(0, 0, 0, 0);
  const diffDays = Math.floor((today - dateOnly) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    return 'Today';
  }
  if (diffDays === 1) {
    return 'Yesterday';
  }
  if (diffDays >= 2 && diffDays <= 14) {
    return `${diffDays} days ago`;
  }

  // Show "Mon D, YYYY"
  const monthsShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthName = monthsShort[dt.getMonth()];
  const day = dt.getDate();
  const year = dt.getFullYear();
  return `${monthName} ${day}, ${year}`;
}

// Get user_id from API key via backend
async function getUserIdFromApiKey(apiKey) {
  try {
    const response = await fetch(`${BACKEND_URL}/api/auth/user-id`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: apiKey })
    });

    if (!response.ok) {
      throw new Error(`Failed to get user_id: ${response.status}`);
    }

    const data = await response.json();
    return data.user_id;
  } catch (error) {
    console.error('❌ Error getting user_id from API key:', error);
    return null;
  }
}

// Submit batch feedback to Cloud Run backend
async function submitBatchFeedback(userId, queryText, sourceApp, globalFeedback, memoryFeedback) {
  try {
    // Get version from manifest.json (single source of truth)
    const manifest = chrome.runtime.getManifest();
    const appVersion = manifest.version;

    const requestBody = {
      user_id: userId,
      query_text: queryText,
      timestamp: new Date().toISOString(),
      source_app: sourceApp, // Dynamic: 'chrome_gmail' or 'chrome_web'
      source_app_version: appVersion,
      global_feedback: globalFeedback,
      memory_feedback: memoryFeedback
    };

    console.log('===== SUBMITTING CHROME FEEDBACK =====');
    console.log(JSON.stringify(requestBody, null, 2));
    console.log('======================================');

    const response = await fetch(`${BACKEND_URL}/api/feedback/batch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Backend error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log('✅ Batch feedback submitted successfully:', result);
    return { success: true, data: result };

  } catch (error) {
    console.error('❌ Error submitting batch feedback:', error);
    return { success: false, error: error.message };
  }
}

// Get API configuration
async function getApiConfig() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['apiKey'], (result) => {
      resolve({
        apiKey: result.apiKey || ''
      });
    });
  });
}

// Store API configuration status
let isApiConfigured = false;

// Check if API is configured
async function checkApiConfiguration() {
  const config = await getApiConfig();
  isApiConfigured = !!config.apiKey;
  return isApiConfigured;
}

// Load memories - now this just signals content scripts that API is ready
async function loadMemoriesFromSheets() {
  console.log('📝 Initializing memory service...');

  try {
    // Ensure environment config is loaded
    await initializeEnvironmentConfig();

    const isConfigured = await checkApiConfiguration();

    if (!isConfigured) {
      console.log('⚠️ API key not configured. Please configure in extension options.');

      const storageData = {
        apiConfigured: false,
        lastUpdated: Date.now(),
        updateSource: 'api'
      };

      chrome.storage.local.set(storageData, async () => {
        console.log('✅ Status updated: API not configured');
        await notifyGmailTabs();
      });
      return;
    }

    // API is configured, let content scripts know
    const storageData = {
      apiConfigured: true,
      lastUpdated: Date.now(),
      updateSource: 'api'
    };

    chrome.storage.local.set(storageData, async () => {
      if (chrome.runtime.lastError) {
        console.error('❌ Failed to store status:', chrome.runtime.lastError);
      } else {
        console.log('✅ API configured and ready');
        await notifyGmailTabs();
      }
    });

  } catch (error) {
    console.error('❌ Failed to initialize memory service:', error);
  }
}

async function notifyGmailTabs() {
  try {
    const allTabs = await chrome.tabs.query({});
    console.log(`🔍 Found ${allTabs.length} total tabs`);

    // Filter out chrome:// and other internal URLs
    const relevantTabs = allTabs.filter(tab => {
      if (!tab.url ||
          tab.url.startsWith('chrome://') ||
          tab.url.startsWith('chrome-extension://') ||
          tab.url.startsWith('about:')) {
        return false;
      }
      return true;
    });

    console.log(`📧 Found ${relevantTabs.length} relevant tabs to notify`);

    for (const tab of relevantTabs) {
      try {
        await chrome.tabs.sendMessage(tab.id, {
          action: 'apiConfigured'
        });
        console.log(`✅ Notified tab ${tab.id}`);
      } catch (err) {
        console.log(`⚠️ Could not notify tab ${tab.id}: ${err.message}`);
      }
    }
  } catch (err) {
    console.error('❌ Error querying/notifying tabs:', err);
  }
}

// Event listeners
chrome.runtime.onInstalled.addListener((details) => {
  console.log('📦 Extension installed/updated:', details.reason);
  loadMemoriesFromSheets();
});

chrome.runtime.onStartup.addListener(() => {
  console.log('🔄 Service worker startup');
  loadMemoriesFromSheets();
});

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Service worker received message:', request);

  if (request.action === 'refreshMemories') {
    console.log('🔄 Manual refresh requested');
    loadMemoriesFromSheets();
    sendResponse({ success: true });
    return true;
  }

  // Handle sign out - clear cached credentials
  if (request.action === 'signOut') {
    console.log('🚪 Sign out requested - clearing cached credentials');
    isApiConfigured = false;
    chrome.storage.local.set({ apiConfigured: false });
    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'startGoogleAuth') {
    (async () => {
      try {
        // Ensure environment config is loaded
        await initializeEnvironmentConfig();

        const senderTabId = sender && sender.tab && Number.isInteger(sender.tab.id) ? sender.tab.id : null;
        const targetTabId = Number.isInteger(request.tabId) ? request.tabId : senderTabId;
        if (chrome.identity?.clearAllCachedAuthTokens) {
          await new Promise((resolve) => chrome.identity.clearAllCachedAuthTokens(resolve));
        }
        const accessToken = await new Promise((resolve, reject) => {
          chrome.identity.getAuthToken({ interactive: true }, (token) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(token);
            }
          });
        });

        const idpResponse = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${FIREBASE_API_KEY}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            postBody: `access_token=${encodeURIComponent(accessToken)}&providerId=google.com`,
            requestUri: 'http://localhost',
            returnIdpCredential: true,
            returnSecureToken: true
          })
        });

        if (!idpResponse.ok) {
          const errorText = await idpResponse.text();
          throw new Error(`Firebase auth failed: ${errorText}`);
        }

        const idpData = await idpResponse.json();
        const idToken = idpData.idToken;

        const authResponse = await fetch(`${AUTH_API_BASE}/v1/auth/login`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${idToken}`,
            'Content-Type': 'application/json'
          }
        });

        if (!authResponse.ok) {
          const errorText = await authResponse.text();
          throw new Error(`Backend auth failed: ${errorText}`);
        }

        const authData = await authResponse.json();

        await new Promise((resolve, reject) => {
          chrome.storage.sync.set({
            apiKey: authData.api_key,
            userId: authData.user_id,
            userName: authData.user_name || idpData.displayName,
            userEmail: idpData.email,
            isGoogleAuth: true
          }, () => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve();
            }
          });
        });

        chrome.storage.local.set({
          apiConfigured: true,
          lastUpdated: new Date().toISOString()
        });

        loadMemoriesFromSheets();

        if (targetTabId !== null) {
          chrome.tabs.reload(targetTabId);
        } else {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs[0] && tabs[0].id) {
              chrome.tabs.reload(tabs[0].id);
            }
          });
        }

        chrome.tabs.query({}, (tabs) => {
          tabs.forEach((tab) => {
            if (tab.id) {
              chrome.tabs.sendMessage(tab.id, { action: 'apiConfigured' });
            }
          });
        });

        sendResponse({
          success: true,
          userName: authData.user_name || idpData.displayName,
          userEmail: idpData.email
        });
      } catch (error) {
        console.error('❌ Google auth failed:', error);
        sendResponse({ success: false, error: error.message || 'Google auth failed' });
      }
    })();
    return true;
  }

  if (request.action === 'getStorageData') {
    chrome.storage.local.get(null, (result) => {
      sendResponse({ success: true, data: result });
    });
    return true;
  }

  // Handle memory search requests from content scripts
  if (request.action === 'searchMemories') {
    (async () => {
      try {
        // Ensure environment config is loaded
        await initializeEnvironmentConfig();

        const config = await getApiConfig();
        if (!config.apiKey) {
          sendResponse({ success: false, error: 'API key not configured' });
          return;
        }

        // Truncate to 1000 characters (use last 1000 - prioritize recent messages in threads)
        const truncatedText = request.text.length > 1000
          ? request.text.slice(-1000)
          : request.text;

        const requestUrl = `${API_BASE_URL}/v1/memories/recall`;

        // Check if debug mode is enabled
        const debugMode = await new Promise((resolve) => {
          chrome.storage.sync.get(['debugMode'], (result) => {
            resolve(result.debugMode || false);
          });
        });

        const formData = new FormData();
        formData.append('text', truncatedText);
        formData.append('top_k', '3');  // Limit to 3 memories for extension

        // DEBUG MODE: Log exact payload being sent to recall route
        if (debugMode) {
          console.log('[DEBUG MODE] RECALL REQUEST PAYLOAD:', {
            url: requestUrl,
            method: 'POST',
            headers: {
              'x-api-key': config.apiKey ? `${config.apiKey.substring(0, 8)}...` : 'none'
            },
            formData: {
              text: truncatedText,
              top_k: '3',
              textLength: truncatedText.length,
              fullText: truncatedText // Full text being sent
            },
            timestamp: new Date().toISOString()
          });
        } else {
          console.log('🔍 Sending API request:', {
            url: requestUrl,
            textLength: truncatedText.length,
            textPreview: truncatedText.substring(0, 100),
            apiKeyPresent: !!config.apiKey,
            apiKeyPrefix: config.apiKey ? config.apiKey.substring(0, 8) : 'none'
          });
        }

        const response = await fetch(requestUrl, {
          method: 'POST',
          headers: {
            'x-api-key': config.apiKey
          },
          body: formData
        });

        if (!response.ok) {
          let errorText;
          try {
            errorText = await response.text();
          } catch (e) {
            errorText = 'Could not read error response';
          }
          console.error('❌ API error details:', {
            status: response.status,
            statusText: response.statusText,
            errorBody: errorText
          });
          throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
        }

        const data = await response.json();

        // Log full API response for debugging
        console.log('📊 Full API Response:', JSON.stringify(data, null, 2));
        console.log('🧠 Memories:', data.memories);
        console.log('❓ Q&A:', data.qa);
        console.log('📄 Chunks:', data.chunks);

        // Log first memory in detail if available
        if (data.memories && data.memories.length > 0) {
          console.log('🔍 First Memory Details:', JSON.stringify(data.memories[0], null, 2));
        }
        if (data.qa && data.qa.length > 0) {
          console.log('🔍 First Q&A Details:', JSON.stringify(data.qa[0], null, 2));
        }
        if (data.chunks && data.chunks.length > 0) {
          console.log('🔍 First Chunk Details:', JSON.stringify(data.chunks[0], null, 2));
        }

        // Transform memories to match Gmail extension expectations
        const transformedMemories = (data.memories || []).map(memory => {
          const formattedWhen = formatWhen(memory.content?.when);

          // Extract entities (people/orgs) from content
          const entities = memory.content?.entities || {};
          const entityNames = Object.keys(entities).filter(name =>
            entities[name] === 'Person' || entities[name] === 'Organization'
          );

          // Get participants from email metadata
          const participants = memory.content?.participants || [];

          // Combine both and deduplicate (prefer participants list as it's more accurate)
          const allPeople = [...new Set([...participants, ...entityNames])];

          // Map backend source names to frontend icon names (same as web app)
          const sourceMapping = {
            'email': 'gmail',
            'gmail': 'gmail',
            'calendar': 'calendar',
            'drive': 'drive',
            'slack': 'slack',
            'contacts': 'contacts',
            'photos': 'photos',
            'youtube': 'youtube',
            'tasks': 'tasks',
            'books': 'books',
            'fit': 'fit',
            'github': 'github',
            'microsoft': 'microsoft',
            'zoom': 'zoom',
            'asana': 'asana',
            'browser': 'browser',
            'text': 'text',
            'pdf': 'pdf',
            'vscode': 'vscode',
            'cursor': 'cursor',
            'claude_code': 'claude_code',
            'claude code': 'claude_code',
            'stream': 'stream'
          };

          // Get the actual source from the API (check multiple possible fields)
          const rawSource = memory.source || memory.content?.where || memory.content?.source || '';
          const normalizedSource = String(rawSource).trim().toLowerCase();
          const mappedSource = sourceMapping[normalizedSource] || normalizedSource;

          return {
            event_id: memory.custom_id,  // Use custom_id as unique identifier
            headline: memory.content?.headline || '',
            narrative: memory.content?.narrative || '',
            participants: allPeople,  // Combined unique list of people
            entities: entityNames,  // Just entities for reference
            entitiesWithTypes: entities,  // Full entities object with types
            when: formattedWhen,
            where: memory.content?.where || '',
            what_and_why: memory.content?.what_and_why || '',
            tags: memory.content?.tags || [],
            similarity: memory.score || 0,
            source: mappedSource,  // Add source field for icon rendering
          };
        });

        // Log first 10 transformed memories to inspect structure
        console.log('===== TRANSFORMED MEMORIES =====');
        const memoriesToLog = transformedMemories.slice(0, 10);
        memoriesToLog.forEach((memory, index) => {
          console.log(`Memory ${index + 1}:`, JSON.stringify(memory, null, 2));
        });
        console.log('================================');

        sendResponse({ success: true, memories: transformedMemories });
      } catch (error) {
        console.error('❌ Error searching memories:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  // Handle chat message requests from content scripts
  if (request.action === 'chatMemories') {
    (async () => {
      try {
        // Ensure environment config is loaded
        await initializeEnvironmentConfig();

        const config = await getApiConfig();
        if (!config.apiKey) {
          sendResponse({ success: false, error: 'API key not configured' });
          return;
        }

        const requestUrl = `${API_BASE_URL}/v1/memories/ask`;
        console.log('💬 Sending chat API request:', {
          url: requestUrl,
          textLength: request.text.length,
          textPreview: request.text.substring(0, 100)
        });

        const formData = new FormData();
        formData.append('text', request.text);

        const response = await fetch(requestUrl, {
          method: 'POST',
          headers: {
            'x-api-key': config.apiKey
          },
          body: formData
        });

        if (!response.ok) {
          let errorText;
          try {
            errorText = await response.text();
          } catch (e) {
            errorText = 'Could not read error response';
          }
          console.error('❌ Chat API error:', {
            status: response.status,
            statusText: response.statusText,
            errorBody: errorText
          });
          throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
        }

        const data = await response.json();
        console.log('💬 Chat API response:', data);

        sendResponse({ success: true, response: data.response || '' });
      } catch (error) {
        console.error('❌ Error in chat request:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  // Handle memory creation (memorize) requests from content scripts
  if (request.action === 'memorizeContent') {
    (async () => {
      try {
        // Ensure environment config is loaded
        await initializeEnvironmentConfig();

        const config = await getApiConfig();
        if (!config.apiKey) {
          sendResponse({ success: false, error: 'API key not configured' });
          return;
        }

        // Get user_id from API key
        const storage = await chrome.storage.sync.get(['userId', 'apiKey']);
        let userId = storage.userId;

        if (!userId && storage.apiKey) {
          userId = await getUserIdFromApiKey(storage.apiKey);
          if (userId) {
            await chrome.storage.sync.set({ userId });
          }
        }

        // Use user_id as user_name if available, otherwise use "Browser User"
        const userName = userId || 'Browser User';

        console.log('💾 Memorizing content:', {
          url: request.url,
          textLength: request.text.length,
          textPreview: request.text.substring(0, 100),
          userName: userName
        });

        // Create a text file blob from the content
        const blob = new Blob([request.text], { type: 'text/plain' });
        const fileName = `browser_${Date.now()}.txt`;

        console.log('📦 Created blob:', {
          size: blob.size,
          type: blob.type,
          fileName: fileName
        });

        const formData = new FormData();
        formData.append('file', blob, fileName);
        formData.append('user_name', userName);
        formData.append('source_type', 'browser');

        // Optional: Add item_id with URL for tracking
        // item_id must contain only alphanumeric characters, underscores, and hyphens
        if (request.url) {
          // Create a safe item_id by replacing invalid characters with underscores
          const safeUrl = request.url
            .replace(/[^a-zA-Z0-9_-]/g, '_')  // Replace non-alphanumeric (except _ and -) with _
            .replace(/_+/g, '_')  // Replace multiple underscores with single underscore
            .substring(0, 100);  // Limit length to avoid too-long IDs
          const itemId = `browser_${safeUrl}_${Date.now()}`;
          formData.append('item_id', itemId);
          console.log('🔖 Generated item_id:', itemId);
        }

        console.log('📤 Sending FormData to API:', {
          fileName: fileName,
          userName: userName,
          source_type: 'browser',
          blobSize: blob.size
        });

        const response = await fetch(`${API_BASE_URL}/v1/memorize`, {
          method: 'POST',
          headers: {
            'x-api-key': config.apiKey
          },
          body: formData
        });

        console.log('📥 API response status:', response.status);

        if (!response.ok) {
          const errorText = await response.text();
          console.error('❌ API error response:', errorText);
          throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
        }

        const data = await response.json();
        console.log('✅ Content memorized successfully:', data);

        sendResponse({ success: true, data: data });
      } catch (error) {
        console.error('❌ Error memorizing content:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  // Handle feedback submission
  if (request.action === 'submitFeedback') {
    (async () => {
      try {
        console.log('📝 Submitting batch feedback to Cloud Run backend...');

        // Get user ID from storage, or fetch it from API key
        const storage = await chrome.storage.sync.get(['userId', 'apiKey']);
        let userId = storage.userId;

        // If no userId cached, get it from API key
        if (!userId && storage.apiKey) {
          console.log('📋 Fetching user_id from API key...');
          userId = await getUserIdFromApiKey(storage.apiKey);

          if (userId) {
            // Cache the user_id for future use
            await chrome.storage.sync.set({ userId });
            console.log('✓ User ID fetched and cached:', userId);
          }
        }

        if (!userId) {
          console.error('❌ Could not get user ID');
          sendResponse({
            success: false,
            error: 'Could not determine user ID. Please check your API key in settings.'
          });
          return;
        }

        // Prepare global feedback
        const globalFeedback = {
          rating: request.globalRating || null,
          comment: request.globalFeedbackText || ''
        };

        // Prepare memory feedback array
        const memoryFeedback = request.memories.map((memory, index) => ({
          memory_id: memory.event_id || `memory_${index}`,
          rank: index + 1,
          rating: memory.rating || null,
          comment: memory.comment || '',
          snapshot: {
            narrative: memory.narrative,
            participants: memory.participants,
            when: memory.when,
            where: memory.where,
            tags: memory.tags,
            similarity: memory.similarity
          }
        }));

        // Determine source_app based on sender tab URL
        const sourceApp = sender.tab && sender.tab.url && sender.tab.url.includes('mail.google.com')
          ? 'chrome_gmail'
          : 'chrome_web';

        console.log(`📍 Feedback source: ${sourceApp} (from ${sender.tab?.url || 'unknown'})`);

        // Submit to Cloud Run backend
        const result = await submitBatchFeedback(
          userId,
          request.emailText || '',
          sourceApp,
          globalFeedback,
          memoryFeedback
        );

        if (result.success) {
          console.log('✅ Feedback submitted successfully');
          sendResponse({ success: true, data: result.data });
        } else {
          sendResponse({ success: false, error: result.error });
        }
      } catch (error) {
        console.error('❌ Error in feedback submission handler:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  // Handle tab audio capture for Google Meet (offscreen document)
  if (request.action === 'startTabCapture') {
    (async () => {
      try {
        console.log('🎤 Starting tab capture via offscreen...');

        const tabId = sender.tab?.id || request.tabId;
        if (!tabId) {
          sendResponse({ success: false, error: 'No tab ID' });
          return;
        }

        if (activeTabCaptureTabId === tabId) {
          sendResponse({ success: true, reused: true });
          return;
        }

        if (activeTabCaptureTabId && activeTabCaptureTabId !== tabId) {
          await ensureOffscreenDocument();
          await sendOffscreenMessage({ action: 'offscreenStopTabCapture' });
          activeTabCaptureTabId = null;
        }

        let streamId = request.streamId || null;
        if (!streamId) {
          streamId = await new Promise((resolve, reject) => {
            chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (id) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
                return;
              }
              if (!id) {
                reject(new Error('No stream ID returned'));
                return;
              }
              resolve(id);
            });
          });
        }

        await ensureOffscreenDocument();
        const response = await sendOffscreenMessage({
          action: 'offscreenStartTabCapture',
          tabId,
          streamId
        });

        if (!response?.success) {
          sendResponse({ success: false, error: response?.error || 'Offscreen start failed' });
          return;
        }

        activeTabCaptureTabId = tabId;
        sendResponse({ success: true });
      } catch (error) {
        console.error('🎤 Error in tab capture:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  if (request.action === 'stopTabCapture') {
    (async () => {
      try {
        await ensureOffscreenDocument();
        const response = await sendOffscreenMessage({
          action: 'offscreenStopTabCapture'
        });
        if (!response?.success) {
          sendResponse({ success: false, error: response?.error || 'Offscreen stop failed' });
          return;
        }
        activeTabCaptureTabId = null;
        sendResponse({ success: true });
      } catch (error) {
        console.error('🎤 Error stopping tab capture:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true;
  }
});

// Set up periodic refresh only if alarms API is available
if (chrome.alarms) {
  chrome.alarms.create('refreshMemories', { periodInMinutes: 30 });

  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'refreshMemories') {
      console.log('⏰ Periodic refresh triggered');
      loadMemoriesFromSheets();
    }
  });
} else {
  console.log('⚠️ Alarms API not available, skipping periodic refresh');
}

// Handle keyboard commands (Ctrl+Shift+X for debug toggle)
if (chrome.commands) {
  chrome.commands.onCommand.addListener(async (command) => {
    if (command === 'toggle-debug') {
      console.log('🐛 Debug toggle command received');
      // Send message to active tab to toggle debug modal
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'toggleDebug' }).catch(() => {
          // Tab might not have content script loaded
          console.log('⚠️ Could not send toggle-debug message to tab');
        });
      }
    }
  });
}

// Action click: start Meet capture on the active tab (grants activeTab)
if (chrome.action) {
  chrome.action.onClicked.addListener(async (tab) => {
    try {
      if (!tab?.id) return;
      await chrome.tabs.sendMessage(tab.id, { action: 'startMeetCapture' });
    } catch (error) {
      console.log('⚠️ Could not send startMeetCapture to tab');
    }
  });
}

// Initial load
console.log('🚀 Service worker initialized, initializing memory service...');
loadMemoriesFromSheets();

} catch (error) {
  console.error('💥 Fatal error in service worker:', error);
}
