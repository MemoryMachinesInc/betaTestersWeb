// recall-inspector.js - Floating button and modal for inspecting recall API requests
// Shows the last recall request payload (URL, headers, form data, timestamp)
// Depends on: core/state.js

(function() {
    'use strict';

    const recallInspector = {};
    const state = window.Engramme.state;

    /**
     * Create the floating recall inspector button in bottom left corner
     */
    recallInspector.createButton = function() {
        // Don't create duplicate buttons
        if (document.getElementById('engramme-recall-inspector-button')) {
            return;
        }

        const inspectorButton = document.createElement('button');
        inspectorButton.id = 'engramme-recall-inspector-button';
        inspectorButton.innerHTML = '🐛';
        inspectorButton.title = 'Show Recall Debug Info (Ctrl+Shift+X)';
        inspectorButton.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 20px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f3f4f6;
            border: 1px solid #d1d5db;
            cursor: pointer;
            font-size: 20px;
            z-index: 999999;
            opacity: 0.4;
            transition: opacity 0.2s, transform 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
        `;

        inspectorButton.addEventListener('mouseenter', () => {
            inspectorButton.style.opacity = '1';
            inspectorButton.style.transform = 'scale(1.1)';
        });

        inspectorButton.addEventListener('mouseleave', () => {
            inspectorButton.style.opacity = '0.4';
            inspectorButton.style.transform = 'scale(1)';
        });

        inspectorButton.addEventListener('click', () => {
            recallInspector.showModal();
        });

        document.body.appendChild(inspectorButton);
        console.log('🔍 Recall inspector button created');
    };

    /**
     * Format text content for display - splits headlines into readable list
     * @param {string} text - The raw text content
     * @returns {string} HTML formatted text
     */
    function formatTextForDisplay(text) {
        if (!text) return '<code style="color: #6b7280;">No text content</code>';

        // Check if this looks like headlines (SF Chronicle, NYT, etc.)
        const headlinePatterns = [
            /^SF Chronicle Headlines:\n/,
            /^NYT Headlines:\n/,
            /^Google Search:/
        ];

        const isHeadlineFormat = headlinePatterns.some(pattern => pattern.test(text));

        if (isHeadlineFormat) {
            // Split by newlines and format as a list
            const lines = text.split('\n').filter(line => line.trim());
            const header = lines[0];
            const items = lines.slice(1);

            if (items.length > 0) {
                const listItems = items.map((item, i) =>
                    `<div style="padding: 8px 12px; background: ${i % 2 === 0 ? '#f3f4f6' : '#e5e7eb'}; border-radius: 4px; margin-bottom: 4px; color: #111; font-size: 13px;">${escapeHtml(item)}</div>`
                ).join('');

                return `
                    <div style="margin-bottom: 8px; color: #6366f1; font-weight: 600; font-size: 13px;">${escapeHtml(header)}</div>
                    <div style="max-height: 300px; overflow-y: auto;">${listItems}</div>
                `;
            }
        }

        // Default: show as plain code block
        return `<code style="color: #111; word-break: break-word; white-space: pre-wrap;">${escapeHtml(text)}</code>`;
    }

    /**
     * Escape HTML to prevent XSS
     * @param {string} str - String to escape
     * @returns {string} Escaped string
     */
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    /**
     * Show the recall inspector modal with payload information
     */
    recallInspector.showModal = function() {
        // Remove existing modal if any
        const existingModal = document.getElementById('engramme-recall-inspector-modal');
        if (existingModal) {
            existingModal.remove();
        }

        const modal = document.createElement('div');
        modal.id = 'engramme-recall-inspector-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        `;

        const modalContent = document.createElement('div');
        modalContent.style.cssText = `
            background: white;
            border-radius: 12px;
            padding: 24px;
            max-width: 800px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        `;

        const payload = state.lastRecallPayload;
        const payloadHTML = payload
            ? `
                <h2 style="margin: 0 0 16px 0; font-size: 18px; font-weight: 600; color: #111;">Last Recall Request Payload</h2>
                <div style="background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; font-family: 'Monaco', 'Menlo', monospace; font-size: 12px; line-height: 1.6;">
                    <div style="margin-bottom: 12px;">
                        <strong style="color: #6366f1;">URL:</strong><br>
                        <code style="color: #111;">${payload.url}</code>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong style="color: #6366f1;">Method:</strong><br>
                        <code style="color: #111;">${payload.method}</code>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong style="color: #6366f1;">Headers:</strong><br>
                        <code style="color: #111;">${JSON.stringify(payload.headers, null, 2)}</code>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong style="color: #6366f1;">Form Data (text):</strong><br>
                        ${formatTextForDisplay(payload.formData.text)}
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong style="color: #6366f1;">Form Data (top_k):</strong><br>
                        <code style="color: #111;">${payload.formData.top_k}</code>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <strong style="color: #6366f1;">Text Length:</strong><br>
                        <code style="color: #111;">${payload.textLength} characters (${payload.textLength > 1000 ? 'truncated to first 1000' : 'not truncated'})</code>
                    </div>
                    <div>
                        <strong style="color: #6366f1;">Timestamp:</strong><br>
                        <code style="color: #111;">${payload.timestamp}</code>
                    </div>
                </div>
            `
            : `
                <h2 style="margin: 0 0 16px 0; font-size: 18px; font-weight: 600; color: #111;">Recall Inspector</h2>
                <p style="color: #6b7280; font-size: 14px;">No recall requests have been made yet. Trigger a memory search to see the payload here.</p>
            `;

        modalContent.innerHTML = `
            ${payloadHTML}
            <button id="engramme-recall-inspector-close" style="
                margin-top: 20px;
                padding: 10px 20px;
                background: #111;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                width: 100%;
                transition: background 0.2s;
            ">Close</button>
        `;

        modal.appendChild(modalContent);
        document.body.appendChild(modal);

        // Close on button click
        document.getElementById('engramme-recall-inspector-close').addEventListener('click', () => {
            modal.remove();
        });

        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });

        // Close on Escape key
        const escapeHandler = (e) => {
            if (e.key === 'Escape') {
                modal.remove();
                document.removeEventListener('keydown', escapeHandler);
            }
        };
        document.addEventListener('keydown', escapeHandler);
    };

    /**
     * Hide the recall inspector modal if it's open
     */
    recallInspector.hideModal = function() {
        const modal = document.getElementById('engramme-recall-inspector-modal');
        if (modal) {
            modal.remove();
        }
    };

    /**
     * Toggle the recall inspector modal
     */
    recallInspector.toggle = function() {
        const modal = document.getElementById('engramme-recall-inspector-modal');
        if (modal) {
            modal.remove();
        } else {
            recallInspector.showModal();
        }
    };

    // Export recallInspector to namespace (keep 'debug' alias for backward compatibility)
    window.Engramme.recallInspector = recallInspector;
    window.Engramme.debug = recallInspector; // Backward compatibility

    console.log('✅ Engramme Recall Inspector module loaded');
})();

