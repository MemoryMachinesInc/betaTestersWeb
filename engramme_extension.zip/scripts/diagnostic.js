// DIAGNOSTIC SCRIPT FOR CHROME EXTENSION
// Copy and paste this into the Chrome Extension's Service Worker console
// (Go to chrome://extensions/ → Enable Developer Mode → Click "service worker" link)

console.log('='.repeat(80));
console.log('CHROME EXTENSION DIAGNOSTIC SCRIPT');
console.log('='.repeat(80));

// Check stored API key
chrome.storage.sync.get(['apiKey', 'userId', 'openaiApiKey'], (result) => {
    console.log('\n📋 STORED CONFIGURATION:');
    console.log('  API Key (first 20 chars):', result.apiKey?.substring(0, 20) || 'NOT SET');
    console.log('  API Key (last 10 chars):', result.apiKey?.substring(result.apiKey.length - 10) || 'NOT SET');
    console.log('  Full API Key Length:', result.apiKey?.length || 0);
    console.log('  User ID:', result.userId || 'NOT SET');
    console.log('  OpenAI Key present:', !!result.openaiApiKey);

    // Check local storage
    chrome.storage.local.get(['apiConfigured', 'lastUpdated', 'updateSource'], (localData) => {
        console.log('\n🔧 LOCAL STATE:');
        console.log('  API Configured:', localData.apiConfigured);
        console.log('  Last Updated:', localData.lastUpdated ? new Date(localData.lastUpdated).toISOString() : 'NEVER');
        console.log('  Update Source:', localData.updateSource);

        // Test API call with stored key
        if (result.apiKey) {
            console.log('\n🔍 TESTING API CALL...');

            // Get environment configuration
            chrome.storage.sync.get(['devModeEnabled', 'selectedEnvironment'], (envResult) => {
                const gatewayURLs = {
                    'dev': 'https://memorymachines-gateway-dev-a5fddsyy.uc.gateway.dev',
                    'staging': 'https://memorymachines-gateway-staging-57wqy7gu.uc.gateway.dev',
                    'prod': 'https://memorymachines-gateway-prod-btf57kda.uc.gateway.dev'
                };
                const selectedEnv = envResult.devModeEnabled && envResult.selectedEnvironment
                    ? envResult.selectedEnvironment
                    : 'prod';
                const apiGatewayURL = gatewayURLs[selectedEnv] || gatewayURLs['prod'];

                console.log(`  Using ${selectedEnv.toUpperCase()} environment: ${apiGatewayURL}`);

                const testText = 'test query for diagnostic';
                const formData = new FormData();
                formData.append('text', testText);
                formData.append('top_k', '1');

                fetch(`${apiGatewayURL}/v1/memories/recall`, {
                    method: 'POST',
                    headers: {
                        'x-api-key': result.apiKey
                    },
                    body: formData
                })
            .then(response => {
                console.log('  API Response Status:', response.status, response.statusText);
                return response.json();
            })
            .then(data => {
                console.log('  API Response Data:');
                if (data.memories && data.memories.length > 0) {
                    console.log('    Memories returned:', data.memories.length);
                    console.log('    First memory user_id:', data.memories[0].user_id);
                    console.log('    First memory custom_id:', data.memories[0].custom_id);
                    console.log('    First memory narrative (100 chars):', data.memories[0].content?.narrative?.substring(0, 100));
                } else {
                    console.log('    No memories returned');
                    console.log('    Response:', JSON.stringify(data, null, 2));
                }
            })
                .catch(error => {
                    console.error('  ❌ API call failed:', error);
                });
            });
        } else {
            console.log('\n⚠️ No API key stored - cannot test API call');
        }
    });
});

console.log('\n' + '='.repeat(80));
console.log('Please share the output above with the investigation');
console.log('='.repeat(80));
